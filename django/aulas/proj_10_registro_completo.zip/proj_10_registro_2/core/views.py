from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from .models import Usuario
from django.contrib.auth.decorators import permission_required
from django.contrib.auth.models import Permission
from .forms import UsuarioCreationForm
def home(request):
    return render(request, 'index.html')


@login_required
def perfil(request):
    return render(request, 'perfil.html')


def autenticacao(request):
    if request.POST:
        username = request.POST['usuario']
        password = request.POST['senha']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('perfil')
        else:
            return render(request, 'registration\login.html')
    else:
        return render(request, 'registration\login.html')


def desconectar(request):
    logout(request)
    return redirect('home')


def cadastro_manual(request):
    user = Usuario.objects.create_user(
        username='admin',
        email='admin@email.com',
        cpf='111',
        nome='Administrador',
        password='123',
        idade=30,
        is_superuser=False)
    
    # permission = Permission.objects.get(codename='permissao_01')
    # user.user_permissions.add(permission)

    permission1 = Permission.objects.get(codename='permissao_01')
    permission2 = Permission.objects.get(codename='permissao_02')
    user.user_permissions.add(permission1, permission2)

    user.save()
    return redirect('home')


@login_required
@permission_required('core.permissao_01')
def pagina_1(request):
    return render(request, 'Teste.html')


def registro(request):
    form = UsuarioCreationForm(request.POST or None)
    if form.is_valid():
          form.save()
          return redirect('login')
    contexto = {
        'form': form
    }
    return render(request, 'registro.html', contexto)