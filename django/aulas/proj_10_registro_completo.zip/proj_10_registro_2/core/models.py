from django.db import models
from django.contrib.auth.models import AbstractUser

class Usuario(AbstractUser):
    nome = models.CharField('Nome', max_length=100)
    idade = models.IntegerField('Idade')
    cpf = models.CharField('CPF', max_length=11, unique=True)

    USERNAME_FIELD = 'cpf'

    class Meta:
        permissions = [
            ("permissao_01", "Poderá acessar a view da pagina_1.html"),
            ("permissao_02", "Poderá visualizar um texto do template")
        ]
